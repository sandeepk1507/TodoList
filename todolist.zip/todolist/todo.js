var myNodelist = document.getElementsByTagName("LI");
var i;
for (i = 0; i < myNodelist.length; i++) {
  addCloseButton(myNodelist[i]);
  addEditButton(myNodelist[i]);
}

function addCloseButton(li) {
  var span = document.createElement("SPAN");
  var txt = document.createTextNode("\u00D7");
  span.className = "close";
  span.appendChild(txt);
  li.appendChild(span);

  span.onclick = function() {
    var div = this.parentElement;
    div.style.display = "none";
  }
}

function addEditButton(li) {
  var span = document.createElement("SPAN");
  var txt = document.createTextNode("Edit");
  span.className = "editBtn";
  span.appendChild(txt);
  li.appendChild(span);

  span.onclick = function() {
    var div = this.parentElement;
    var inputValue = prompt("Edit the task:", div.childNodes[0].nodeValue);
    if (inputValue !== null) {
      div.childNodes[0].nodeValue = inputValue;
    }
  }
}

var list = document.querySelector('ul');
list.addEventListener('click', function(ev) {
  if (ev.target.tagName === 'LI') {
    ev.target.classList.toggle('checked');
  }
}, false);

function newElement() {
  var li = document.createElement("li");
  var inputValue = document.getElementById("myInput").value;
  var t = document.createTextNode(inputValue);
  li.appendChild(t);
  if (inputValue === '') {
    alert("You must write something!");
  } else {
    document.getElementById("myUL").appendChild(li);
    addCloseButton(li);
    addEditButton(li);
  }
  document.getElementById("myInput").value = "";
}
 ``